package sample;

/**
 * Angel Laureano
 * Carri Rodabaugh
 * CS-1181L-06
 * Project 4
 * The class below is going to control how each method is done in a particular order
 * and it will also call the classes needed to perform the given task
 */

import java.util.LinkedList;
import java.util.Queue;

public class InsertionSort implements Runnable {

    int array[];
    public Queue<int[]> myQueue = new LinkedList<int[]>();
    public InsertionSort(int[] array,Queue<int[]> myQueue){
        this.array=array;
        this.myQueue=myQueue;
    }

    public int[] instertion(int [] array,Queue<int[]> myQueue){
        int temp;
        for (int i = 1; i < array.length; i++) {
            for(int j = i ; j > 0 ; j--){
                if(array[j] < array[j-1]){
                    temp = array[j];
                    array[j] = array[j-1];
                    array[j-1] = temp;
                }
            }
        }
        return array;
    }

    @Override
    public void run() {
        int ai[]=instertion(array,myQueue);
        myQueue.add(ai);



    }
}
