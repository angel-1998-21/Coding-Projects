package sample;

/**
 * Angel Laureano
 * Carri Rodabaugh
 * CS-1181L-06
 * Project 4
 * The class below is going to call the FXMLLoader for the animations and it will
 * set the given parameters for it from the sample class
 */

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Main extends Application {

    public void as(){}

    @Override
    public void start(Stage primaryStage) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("sample.fxml"));
        primaryStage.setTitle("Project 4");
        primaryStage.setScene(new Scene(root, 350, 450));
        primaryStage.show();
    }


    public static void main(String[] args) {
        launch(args);
    }
}
