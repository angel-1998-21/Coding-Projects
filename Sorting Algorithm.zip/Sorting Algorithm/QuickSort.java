package sample;

/**
 * Angel Laureano
 * Carri Rodabaugh
 * CS-1181L-06
 * Project 4
 * The class below is going to sort the given array using the quick sort method
 * and it will tell the user how long it took to sort it
 */

import java.util.LinkedList;
import java.util.Queue;

public class QuickSort implements Runnable {

    public Queue<int[]> myQueue = new LinkedList<int[]>();
    int [] array;
    int low;
    int high;
    public QuickSort(int[] array,int low,int high,Queue<int[]> myQueue){
        this.array=array;
        this.low=low;
        this.high=high;
        this.myQueue=myQueue;
    }

    public  int []  quickSort(int[] arr, int low, int high,Queue<int[]> myQueue) {


        // pick the pivot
        int middle = low + (high - low) / 2;
        int pivot = arr[middle];
        // make left < pivot and right > pivot
        int i = low, j = high;
        while (i <= j) {
            while (arr[i] < pivot) {
                i++;
            }

            while (arr[j] > pivot) {
                j--;
            }

            if (i <= j) {
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
                i++;
                j--;
            }
        }
        // recursively sort two sub parts
        if (low < j)
            quickSort(arr, low, j,myQueue);

        if (high > i)
            quickSort(arr, i, high,myQueue);

        return arr;

    }



    @Override
    public void run() {

        int ai[]= quickSort(array,0,array.length-1,myQueue);
        myQueue.add(ai);

    }
}


