package sample;

/**
 * Angel Laureano
 * Carri Rodabaugh
 * CS-1181L-06
 * Project 4
 * The class below is going to sort the given array as a bubble sort and it will
 * tell the user how long it took to sort the array
 */

import java.util.LinkedList;
import java.util.Queue;

public class BubbleSort implements Runnable{
    int array[];
    public Queue<int[]> myQueue = new LinkedList<int[]>();
    public BubbleSort(int array[],Queue<int[]> myQueue){
        this.array=array;
        this.myQueue=myQueue;
    }

    public int [] bubbleSort(int[] array){

        int n = array.length;
        int temp = 0;
        for (int i = 0; i < n; i++) {
            for (int j = 1; j < (n - i); j++) {
                if (array[j - 1] > array[j]) {
                    //swap elements
                    temp = array[j - 1];
                    array[j - 1] = array[j];
                    array[j] = temp;
                }

            }
        }

        return array;
    }

    @Override
    public void run() {
        int ai[]=bubbleSort(array);
        myQueue.add(ai);
    }
}
