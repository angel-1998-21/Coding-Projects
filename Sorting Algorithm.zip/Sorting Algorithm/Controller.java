package sample;

/**
 * Angel Laureano
 * Carri Rodabaugh
 * CS-1181L-06
 * Project 4
 * The class below is going to control how each method is done in a particular order
 * and it will also call the classes needed to perform the given task
 */
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;


import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;


public class Controller {


    public static Queue<int[]> myQueue = new LinkedList<int[]>();
    public RadioButton sortedId;
    public RadioButton reversId;
    public RadioButton randomid;
    public RadioButton selectId;
    public RadioButton bubbleId;
    public RadioButton insertionId;
    public RadioButton quickID;
    ArrayDeque<int[]> aDeque = new ArrayDeque<int[]>();
    public static int[][] chunkArray(int[] array, int chunkSize) {
        int numOfChunks = (int)Math.ceil((double)array.length / chunkSize);
        int[][] output = new int[numOfChunks][];

        for(int i = 0; i < numOfChunks; ++i) {
            int start = i * chunkSize;
            int length = Math.min(array.length - start, chunkSize);
            int[] temp = new int[length];
            System.arraycopy(array, start, temp, 0, length);
            output[i] = temp;
        }
        return output;
    }

    public void merge() throws InterruptedException {

        int[] array;
        int[] array1;
        while (myQueue.size()>1){
              array = myQueue.poll();
              array1 = myQueue.poll();
            int[] merged = concatenate(array,array1);
            Runnable b = new BubbleSort(merged,myQueue);
            Thread thread = new Thread(b);
            thread.start();
            thread.join();
        }

            int[] result = myQueue.poll();
        for(int i =0 ;i < result.length;i++ ){
            System.out.print(result[i]+",");
        }
    }

    public int[] concatenate (int[] a, int[] b) {
        int aLen = a.length;
        int bLen = b.length;
        int[] c = new int[aLen+bLen];
        System.arraycopy(a, 0, c, 0, aLen);
        System.arraycopy(b, 0, c, aLen, bLen);

        return c;
    }

    public void chunk(int [][] array) throws InterruptedException {

        Runnable algo = null;


        ExecutorService es = Executors.newCachedThreadPool();

        for(int i=0;i<array.length;i++){
            Runnable b = null;
            if(selectId.isSelected()){
                b = new Selection(array[i],myQueue);
            }else if(bubbleId.isSelected()){
                b = new BubbleSort(array[i],myQueue);
            }else if(quickID.isSelected()){
                b = new QuickSort(array[i],0,array[i].length-1,myQueue);
            }else if(insertionId.isSelected()){
                b = new InsertionSort(array[i],myQueue);
            }


            es.execute(b);
        }
        es.shutdown();
        boolean finshed = es.awaitTermination(2, TimeUnit.MINUTES);

    }

    public int [] generateRandomArray(int size ){
        int arryrandom[]= new int[size];
        for(int i=0;i<arryrandom.length;i++){
            Random r = new Random();
            int randomInt = r.nextInt(100) + 1;
            arryrandom[i]=randomInt;
                    }
           return arryrandom;
    }

    public int [] alreadySort(int lenght){
        int[] arr = new int[lenght];
        for(int i =0 ; i < lenght;i++)
            arr[i] = i;
        return arr;
    }

    public int [] reverseOrder(int length){
       int[] arraydesending = new int[length];
       for(int i = length; i < length; i--){
          arraydesending[i]= i;
      }
     return arraydesending;
    }

    @FXML
    TextField inputSizeText= new TextField();
    @FXML
    TextField sizeBlockText= new TextField();
    

    @FXML
    public void onClick(ActionEvent actionEvent) {
        long startTime = System.currentTimeMillis();

        int inputSize= Integer.parseInt(inputSizeText.getText());
        int[] array  = new int[inputSize];
        if(sortedId.isSelected()){
            array = alreadySort(inputSize);
        }else if(reversId.isSelected()){
            array = reverseOrder(inputSize);
        }else if(randomid.isSelected()){
            array = generateRandomArray(inputSize);
        }
        int sizeofBlock= Integer.parseInt(sizeBlockText.getText());
        int [][] ar=chunkArray(array,sizeofBlock);


        try {
            chunk(ar);
            merge();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        long endTime   = System.currentTimeMillis();
        long totalTime = endTime - startTime;

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Thread Sorted!");
        alert.setHeaderText("Finished");
        alert.setContentText("Sort completed in " + totalTime + " milliseconds ");
        alert.showAndWait();

    }


}
