package sample;

/**
 * Angel Laureano
 * Carri Rodabaugh
 * CS-1181L-06
 * Project 4
 * The class below is going to sort the given array using the selection sort and it 
 * will tell the user how long it took to sort the array
 */

import java.util.LinkedList;
import java.util.Queue;


public class Selection implements Runnable {

    int [] array;
    public Queue<int[]> myQueue = new LinkedList<int[]>();
    public Selection(int[] array,Queue<int[]> myQueue){
        this.array=array;
        this.myQueue=myQueue;

    }

    public  int[] selectionSort(int[] arr,Queue<int[]> myQueue){
        for (int i = 0; i < arr.length - 1; i++)
        {
            int index = i;
            for (int j = i + 1; j < arr.length; j++){
                if (arr[j] < arr[index]){
                    index = j;//searching for lowest index
                }
            }
            int smallerNumber = arr[index];
            arr[index] = arr[i];
            arr[i] = smallerNumber;
        }
        return arr;
    }
    @Override
    public void run() {
        int ai[]=selectionSort(array,myQueue);
        myQueue.add(ai);

    }
}
