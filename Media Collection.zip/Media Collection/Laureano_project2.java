package laureano_project2;


import java.util.ArrayList;
import java.util.Collections;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * Angel Laureano
 * Carri Rodabaugh
 * CS-1181L-06
 * Project 2
 * In this project, we will take project 1 and add GUI to it 
 */
public class Laureano_project2 extends Application {

    private final ListView lvOut = new ListView();

    @Override
    public void start(Stage primaryStage) throws Exception {

        ArrayList<MediaList> mediaList = new ArrayList<>();

        Label label1 = new Label("Title:     ");
        TextField tfl = new TextField();
        HBox hBox = new HBox();

        Label label2 = new Label("Format: ");
        TextField tfl2 = new TextField();
        HBox hbox = new HBox();

        Label label3 = new Label("Loaned To: ");
        TextField tfl3 = new TextField();
        HBox hBox2 = new HBox();

        Label label4 = new Label("Loaned On: ");
        TextField loanOnTextField = new TextField();
        HBox loanOnHBox = new HBox();

        String mediaTitle = tfl.getText();
        String mediaFormat = tfl2.getText();
        String nameOfLoaner = "";
        String dateOfLoan = "";
        MediaList newMedia = new MediaList(mediaTitle, mediaFormat, nameOfLoaner, dateOfLoan);

        MediaList testMedia1 = new MediaList("Battlegrounds", "Xbox One", "Michael", "10/12/2017");
        mediaList.add(testMedia1);
        
        

        
        
        ObservableList oList = FXCollections.observableArrayList(mediaList);
        lvOut.setItems(oList);
        lvOut.refresh();

        Button addBtn = new Button();

        addBtn.setText("Add");

        addBtn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event) {
                Boolean add = true;
                String mediaTitle = tfl.getText();
                String mediaFormat = tfl2.getText();
                String nameOfLoaner = "";
                String dateLoan = "";

                newMedia.setMediaTitle(mediaTitle);
                newMedia.setMediaFormat(mediaFormat);
                newMedia.setNameOfLoaner(nameOfLoaner);
                newMedia.setLoanDate(dateLoan);

                if (mediaTitle.isEmpty() || mediaFormat.isEmpty()) {
                    System.out.println("Please input a title and format.");
                    add = false;
                } else if (add == true) {
                    for (int i = 0; i < mediaList.size(); i++) {
                        
                        if (mediaList.get(i).getMediaTitle().equals(mediaTitle) && mediaList.get(i).getMediaFormat().equals(mediaFormat)) {//checks to see if the item the user wants to add is alread on the list
                            add = false;
                        }
                    }
                    if (add == true) {
                        
                        MediaList newMedia = new MediaList(mediaTitle, mediaFormat, nameOfLoaner, dateLoan);
                        mediaList.add(newMedia);

                        System.out.println("The item has been added to the list.");

                    } else {
                        System.out.println("The list already contains an item named: " + mediaTitle + " in the format: " + mediaFormat);
                    }

                }
                ObservableList oList = FXCollections.observableArrayList(mediaList);
                lvOut.setItems(oList);
                lvOut.refresh();
            }

        }
        );

        Button removeBtn = new Button();

        removeBtn.setText("Remove");

        removeBtn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event
            ) {

                Boolean remove = false;
                String mediaTitle = tfl.getText();
                String mediaFormat = tfl2.getText();
                String loanerName = "";
                String dateOfLoan = "";

                newMedia.setMediaTitle(mediaTitle);
                newMedia.setMediaFormat(mediaFormat);
                newMedia.setNameOfLoaner(loanerName);
                newMedia.setLoanDate(dateOfLoan);

                for (int i = 0; i < mediaList.size(); i++) {

                    if (mediaList.get(i).getMediaTitle().equals(mediaTitle) && mediaList.get(i).getMediaFormat().equals(mediaFormat)) {//checks to make sure the item the user wants to remove is on the list
                        mediaList.remove(i);
                        System.out.println("The item has been removed from the list.");
                        remove = true;
                    }
                }
                if (remove == false && !mediaList.isEmpty()) {
                    System.out.println("The list does not contain an item named: " + mediaTitle + " in the format: " + mediaFormat);

                } else if (mediaList.isEmpty()) {
                    System.out.println("The list is empty.");
                }
                ObservableList oList = FXCollections.observableArrayList(mediaList);
                lvOut.setItems(oList);
                lvOut.refresh();
            }
        }
        );

        Button loanBtn = new Button();

        loanBtn.setText(
                "Loan");

        loanBtn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event
            ) {

                String loanerName = tfl3.getText();
                String loanDate = loanOnTextField.getText();
                String mediaTitle = tfl.getText();
                String mediaFormat = tfl2.getText();
                Boolean loan = false;

                for (int i = 0; i < mediaList.size(); i++) {

                    if (mediaList.get(i).getMediaTitle().equals(mediaTitle) && mediaList.get(i).getMediaFormat().equals(mediaFormat)) {
                        mediaList.get(i).setNameOfLoaner(loanerName);
                        mediaList.get(i).setLoanDate(loanDate);
                        System.out.println(mediaTitle + " Which is a " + mediaFormat + " has been loaned to " + loanerName + " on " + loanDate + ".");
                        loan = true;
                    }
                }
                if (loan == false && !mediaList.isEmpty()) {
                    System.out.println(mediaTitle + " is not on the list");
                } else if (mediaList.isEmpty() && !loanerName.isEmpty()) {
                    System.out.println("There is no item on the list to be loaned.");
                } else if (loanerName.isEmpty()) {
                    System.out.println("You need to enter an item name to loan.");
                }
                ObservableList oList = FXCollections.observableArrayList(mediaList);
                lvOut.setItems(oList);
                lvOut.refresh();
            }

        }
        );

        Button returnBtn = new Button();

        returnBtn.setText(
                "Return");

        returnBtn.setOnAction(new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event
            ) {
                Boolean remove = false;
                String loanerName = tfl3.getText();
                String loanDate = loanOnTextField.getText();
                String mediaTitle = tfl.getText();
                String mediaFormat = tfl2.getText();

                for (int i = 0; i < mediaList.size(); i++) {
                    
                    if (mediaList.get(i).getMediaTitle().equals(mediaTitle) && mediaList.get(i).getMediaFormat().equals(mediaFormat) && mediaList.get(i).getNameOfLoaner().isEmpty()) {
                        remove = false;
                        
                    } else if (mediaList.get(i).getMediaTitle().equals(mediaTitle) && mediaList.get(i).getMediaFormat().equals(mediaFormat)) {
                        mediaList.get(i).setNameOfLoaner("");
                        mediaList.get(i).setLoanDate("");
                        System.out.println("The item has been returned.");
                        remove = true;
                    }

                }
                if (remove == false) {
                    System.out.println("That item is not one that is on the list. ");
                }
                ObservableList oList = FXCollections.observableArrayList(mediaList);
                lvOut.setItems(oList);
                lvOut.refresh();
            }
        }
        );

        RadioButton rb1 = new RadioButton("By title");

        rb1.setOnAction(
                new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event
            ) {
                Collections.sort(mediaList, MediaList.getAttribute1Comparator());

                ObservableList oList = FXCollections.observableArrayList(mediaList);
                lvOut.setItems(oList);
                lvOut.refresh();
            }

        }
        );

        RadioButton rb2 = new RadioButton("By date loaned");

        rb2.setOnAction(
                new EventHandler<ActionEvent>() {

            @Override
            public void handle(ActionEvent event
            ) {
                Collections.sort(mediaList, MediaList.getAttribute2Comparator().reversed());

                ObservableList oList = FXCollections.observableArrayList(mediaList);
                lvOut.setItems(oList);
                lvOut.refresh();
            }

        }
        );

        hBox.getChildren().addAll(label1, tfl);
        hbox.getChildren().addAll(label2, tfl2);
        hBox2.getChildren().addAll(label3, tfl3, loanBtn);
        loanOnHBox.getChildren().addAll(label4, loanOnTextField);

        Label l5 = new Label("Sort");

        String cssLayout = "-fx-border-color: black;";

        VBox vb1 = new VBox(20);

        vb1.getChildren().addAll(hBox, hbox, addBtn);
        VBox vb2 = new VBox(20);

        vb2.getChildren().addAll(removeBtn, returnBtn);
        VBox vb3 = new VBox(20);

        vb3.getChildren().addAll(hBox2, loanOnHBox, loanBtn);
        VBox vb4 = new VBox(20);

        vb4.getChildren().addAll(l5, rb1, rb2);

        vb1.setStyle(cssLayout);
        vb3.setStyle(cssLayout);

        
        GridPane gp = new GridPane();

        gp.setHgap(10);
        gp.setVgap(10);

        
        gp.add(lvOut, 0, 0, 1, 4);
        gp.add(vb1, 1, 0);
        gp.add(vb2, 1, 1);
        gp.add(vb3, 1, 2);
        gp.add(vb4, 1, 3);
        gp.getBorder();

        Scene scene = new Scene(gp, 550, 500);

        primaryStage.setTitle("Media Collection");
        primaryStage.setScene(scene);

        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     * @param mediaList
     */
    public static void main(String[] args, ArrayList<MediaList> mediaList) {
        launch(args);

    }

}



