package laureano_project2;

import java.util.Comparator;

/**
 * Angel Laureano
 * Carri Rodabaugh
 * CS-1181L-06
 * Project 2
 * This class is going to set the getters and setter for the media in the array list
 * and it will print and compare the media alphabetically
 */
public class MediaList implements Comparable<MediaList> {

    private String mediaTitle = "";
    private String mediaFormat = "";
    private String nameOfLoaner = "";
    private String loanDate = "";

    public MediaList(String title, String format, String name, String date) {
        this.mediaTitle = title;
        this.mediaFormat = format;
        this.nameOfLoaner = name;
        this.loanDate = date;
    }

    public String getMediaTitle() {
        return mediaTitle;
    }

    public void setMediaTitle(String mediaTitle) {
        this.mediaTitle = mediaTitle;
    }

    public String getMediaFormat() {
        return mediaFormat;
    }

    public void setMediaFormat(String mediaFormat) {
        this.mediaFormat = mediaFormat;
    }

    public String getNameOfLoaner() {
        return nameOfLoaner;
    }

    public void setNameOfLoaner(String nameOfLoaner) {
        this.nameOfLoaner = nameOfLoaner;
    }

    public String getLoanDate() {
        return loanDate;
    }

    public void setLoanDate(String loanDate) {
        this.loanDate = loanDate;
    }
/**
 *
 * @return 
 */
    @Override
    public String toString() {

        if (this.nameOfLoaner.isEmpty()) {
            return "title: " + mediaTitle + "" + " format: " + mediaFormat + "";
        } else {
            return "title: " + mediaTitle + "" + " format: " + mediaFormat + " (Loaned to: " + nameOfLoaner + "" + " on: " + loanDate + ")";
        }
    }

    /**
     *
     * @param o
     * @return
     */
    @Override
    public int compareTo(MediaList o) {

        return 0;

    }
/**
 * @return 
 */
   static Comparator<MediaList> getAttribute1Comparator() {
        return new Comparator<MediaList>() {
            @Override
            public int compare(MediaList o1, MediaList o2) {
                String item1 = o1.mediaTitle;
                String item2 = o2.mediaTitle;

                return item1.compareToIgnoreCase(item2);
            }
           
        };
    }
/**
 * @return 
 */
  static  Comparator<MediaList> getAttribute2Comparator() {
        return new Comparator<MediaList>() {
            @Override
            public int compare(MediaList o1, MediaList o2) {
                String item1 = o1.loanDate;
                String item2 = o2.loanDate;
                return item1.compareToIgnoreCase(item2);
            }
            
        };
    }

}
