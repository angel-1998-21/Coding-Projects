package com.nvt.boxio.view.activity;

import android.app.AlertDialog;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.Scopes;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.nvt.boxio.R;

import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = MainActivity.class.getSimpleName();
    private NavController navController;
    public GoogleSignInClient mGoogleSignInClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestScopes(new Scope(Scopes.DRIVE_APPFOLDER))
                .requestEmail()
                .build();
        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);
        navController = Navigation.findNavController(this, R.id.nav_host);
    }

    @Override
    public void onStart() {
        super.onStart();


    }


    // [START handleSignInResult]
    public void handleSignInResult(@Nullable Task<GoogleSignInAccount> completedTask) {
        Log.d(TAG, "handleSignInResult:" + completedTask.isSuccessful());

        try {
            // Signed in successfully, show authenticated U
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);
            updateUI(account);
        } catch (ApiException e) {
            // Signed out, show unauthenticated UI.
            makeToast("Login failed !");
            Log.w(TAG, "handleSignInResult:error", e);
            updateUI(null);
        }
    }

    public void updateUI(GoogleSignInAccount account) {
        if (account != null) {
            Log.d(TAG, "updateUI: " + account.toString());
            makeToast(String.format(getString(R.string.welcome), account.getDisplayName()));

        }
    }


    @Override
    public boolean onSupportNavigateUp() {
        return navController.navigateUp();
    }


    // [END signIn]
    public GoogleSignInAccount getLastAccountSignIn() {

        // Check if the user is already signed in and all required scopes are granted
        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
        if (account != null && GoogleSignIn.hasPermissions(account, new Scope(Scopes.DRIVE_APPFOLDER))) {
            updateUI(account);
        } else {
            updateUI(null);
        }
        return account;
    }

    // [START signOut]
    public void signOut() {
        mGoogleSignInClient.signOut().addOnCompleteListener(this, new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                // [START_EXCLUDE]
                updateUI(null);
                navController.popBackStack(R.id.loginFragment, false);
                makeToast("Sign out successfully !");
                // [END_EXCLUDE]
            }
        });
    }

    public void makeToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show();
    }

    Fragment getCurrentFragment() {
        return getSupportFragmentManager().findFragmentById(R.id.content_main);
    }

    @Override
    public void onBackPressed() {
        if (navController.getCurrentDestination() != null && navController.getCurrentDestination().getId() == R.id.networkFragment)
            showLogoutDialog();

        else super.onBackPressed();

    }

    public void showLogoutDialog() {
        AlertDialog.Builder alertDialog = makeAlertDialog("Google Account logout","Are you sure");
        alertDialog.setPositiveButton("YES",
                (dialog, which) -> {
                    signOut();
                    dialog.dismiss();
                });

        alertDialog.setNegativeButton("NO",
                (dialog, which) -> dialog.cancel());

        alertDialog.show();
    }
    public AlertDialog.Builder makeAlertDialog(String title, String message){
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(this);
        alertDialog.setTitle(title);
        alertDialog.setMessage(message);
        return alertDialog;
    }
}
