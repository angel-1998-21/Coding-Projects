package com.nvt.boxio.view.fragment;

import android.widget.TextView;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.navigation.fragment.NavHostFragment;

import com.nvt.boxio.R;
import com.nvt.boxio.base.BaseFragment;
import com.nvt.boxio.constant.LockStatus;

import butterknife.BindView;
import butterknife.OnClick;

public class MainFragment extends BaseFragment {
    @BindView(R.id.current_state)
    TextView currentState;
    MutableLiveData<LockStatus> status = new MutableLiveData<>();
    @Override
    protected int setViewID() {
        return R.layout.fragment_main;
    }

    @Override
    protected void initUI() {
        status.setValue(LockStatus.Locked);
        status.observe(this, new Observer<LockStatus>() {
            @Override
            public void onChanged(LockStatus lockStatus) {
                currentState.setText(lockStatus.toString());
            }
        });
    }

    @OnClick(R.id.live)
    void goLive() {
        NavHostFragment.findNavController(this).navigate(R.id.liveActivity);
    }

    @OnClick(R.id.google_drive)
    void openGoogleDrive() {
        NavHostFragment.findNavController(this).navigate(R.id.googleDriveActivity);
    }

    @OnClick(R.id.sign_out)
    void signOut() {
        mActivity.showLogoutDialog();
    }
    @OnClick(R.id.lock_unlock)
    void lockOrUnlock(){
        if(status.getValue() == LockStatus.Locked)status.setValue(LockStatus.Unlocked);
        else status.setValue(LockStatus.Locked);
    }
}
