package com.nvt.boxio.constant;

public enum LockStatus{
    Locked,Unlocked
}
