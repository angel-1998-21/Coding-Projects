package com.nvt.boxio.view.activity;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.nvt.boxio.R;
import com.nvt.boxio.base.BaseActivity;

import butterknife.OnClick;

public class GoogleDriveActivity extends BaseActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        setContentView(R.layout.activity_google_drive);
        super.onCreate(savedInstanceState);
    }
    @OnClick(R.id.close)
    void close(){
        finish();
    }
}
