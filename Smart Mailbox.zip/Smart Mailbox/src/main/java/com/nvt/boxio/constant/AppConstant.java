package com.nvt.boxio.constant;

public class AppConstant {
    public static final int RC_SIGN_IN = 9001;
}
