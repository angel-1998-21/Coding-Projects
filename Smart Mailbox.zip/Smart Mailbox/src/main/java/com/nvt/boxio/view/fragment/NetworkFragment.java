package com.nvt.boxio.view.fragment;

import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiManager;
import android.text.TextUtils;
import android.widget.EditText;

import androidx.navigation.fragment.NavHostFragment;

import com.nvt.boxio.R;
import com.nvt.boxio.base.BaseFragment;

import butterknife.BindView;
import butterknife.OnClick;

import static android.content.Context.WIFI_SERVICE;

public class NetworkFragment extends BaseFragment {
    @BindView(R.id.network_ssid)
    EditText networkSSIDInput;
    @BindView(R.id.network_password)
    EditText networkPassword;

    @Override
    protected int setViewID() {
        return R.layout.fragment_network_connect;
    }

    @Override
    protected void initUI() {


    }

    @OnClick(R.id.connect_network)
    void connectNetwork() {
        String ssid = networkSSIDInput.getText().toString().trim();
        String key = networkPassword.getText().toString();
        if (TextUtils.isEmpty(ssid)) mActivity.makeAlertDialog("Network connection", "SSID is require !").show();
        else if (TextUtils.isEmpty(key))
            mActivity.makeAlertDialog("Network connection", "Network key is require !").show();
        else {
            WifiConfiguration wifiConfig = new WifiConfiguration();
            wifiConfig.SSID = String.format("\"%s\"", ssid);
            wifiConfig.preSharedKey = String.format("\"%s\"", key);

            WifiManager wifiManager = (WifiManager) mActivity.getApplicationContext().getSystemService(WIFI_SERVICE);
            int netId;
            if (wifiManager != null) {
                netId = wifiManager.addNetwork(wifiConfig);
                wifiManager.disconnect();
                wifiManager.enableNetwork(netId, true);
                wifiManager.reconnect();
            }

            NavHostFragment.findNavController(this).navigate(R.id.mainFragment);
        }
    }

}
