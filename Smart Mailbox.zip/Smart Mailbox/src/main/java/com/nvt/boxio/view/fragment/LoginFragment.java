package com.nvt.boxio.view.fragment;


import android.content.Intent;

import androidx.annotation.Nullable;
import androidx.navigation.fragment.NavHostFragment;

import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.tasks.Task;
import com.nvt.boxio.R;
import com.nvt.boxio.base.BaseFragment;

import butterknife.BindView;
import butterknife.OnClick;

import static com.nvt.boxio.constant.AppConstant.RC_SIGN_IN;


public class LoginFragment extends BaseFragment {
    @BindView(R.id.sign_in_button)
    SignInButton signInButton;

    @Override
    protected int setViewID() {
        return R.layout.fragment_login;
    }

    @Override
    protected void initUI() {
        GoogleSignInAccount account = mActivity.getLastAccountSignIn();
        if (account != null){
            mActivity.makeToast(String.format(getString(R.string.welcome),account.getDisplayName()));
            NavHostFragment.findNavController(this).navigate(R.id.networkFragment);
        }

    }

    @OnClick(R.id.sign_in_button)
    void signIn() {
        Intent signInIntent = mActivity.mGoogleSignInClient.getSignInIntent();
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            mActivity.handleSignInResult(task);
           if(task.isSuccessful()) NavHostFragment.findNavController(this).navigate(R.id.networkFragment);
        }
    }
}
