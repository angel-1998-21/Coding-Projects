package com.ass.testweather;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class DataManager extends SQLiteOpenHelper{

	private SQLiteDatabase m_Database;
    public static String DBFILE_NAME = "reports.db";
    public static String DATABASE = "reports";
	public static String REPORT_TABLE = "reports";
	private final static int DATABASE_VERSION = 7;

    public ArrayList<Report> ary_reports = new ArrayList<>();


	public DataManager(Context context){
		super(context, DATABASE, null, DATABASE_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		// TODO Auto-generated method stub
		
	}

	public void Open(String path) throws SQLException {
		try {
			m_Database = SQLiteDatabase.openDatabase(path, null, SQLiteDatabase.OPEN_READWRITE);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public void insertReport(Report report) {
		ContentValues contentValues = new ContentValues();
		contentValues.put("id", report.id);
		contentValues.put("title", report.title);
		contentValues.put("location", report.location);
		contentValues.put("date", report.date);
		contentValues.put("note", report.note);
		contentValues.put("temperature", report.temperature);
		contentValues.put("weather_condition", report.weather_condition);
		contentValues.put("photo_name", report.photo_name);
    	long res = m_Database.insert(REPORT_TABLE, null, contentValues);
	}

	public void getReports(String title) {
		String query = "SELECT id, title, location, date, note, temperature, weather_condition, photo_name FROM " + REPORT_TABLE;
		if (title != null && !title.isEmpty()) {
			query += " WHERE title like '%" + title + "%'";
		}

		Cursor cursor = m_Database.rawQuery(query, null);
		int count = cursor.getCount();
		ary_reports.clear();
		for (int i = 0; i < count; i++) {
			cursor.moveToPosition(i);
			Report report = new Report();
			report.id = cursor.getLong(0);
			report.title = cursor.getString(1);
			report.location = cursor.getString(2);
			report.date = cursor.getString(3);
			report.note = cursor.getString(4);
			report.temperature = cursor.getDouble(5);
			report.weather_condition = cursor.getString(6);
			report.photo_name = cursor.getString(7);
			ary_reports.add(report);
		}
		cursor.close();
	}
}
