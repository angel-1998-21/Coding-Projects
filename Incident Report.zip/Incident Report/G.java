package com.ass.testweather;

import java.text.SimpleDateFormat;

public class G {
    public static DataManager db;
    public static SimpleDateFormat sdformat_MMddyyyy = new SimpleDateFormat("MM/dd/yyyy");

}
