package com.ass.testweather;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;


import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;


public class MainActivity extends AppCompatActivity {

    // Preference
    private boolean bDBCreated = false;
    private SharedPreferences prefs;

    Button btnBrowse;
    Button btnRegister;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnBrowse = findViewById(R.id.btn_browse_reports);
        btnBrowse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, BrowseActivity.class);
                startActivity(i);
            }
        });
        btnRegister = findViewById(R.id.btn_new_report);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, RegisterActivity.class);
                startActivity(i);
            }
        });
        loadPreference();
        loadData();
    }

    private void loadPreference() {
        prefs = getSharedPreferences("incident", 0);
        bDBCreated = prefs.getBoolean("db_created", false);
    }

    private void savePreference() {
        SharedPreferences.Editor ed = prefs.edit();
        ed.putBoolean("db_created", bDBCreated);
        ed.commit();
    }

    public boolean loadData() {
        //for copy database
        String destDir = "/data/data/" + getPackageName() + "/databases/";
        String destPath = destDir + DataManager.DBFILE_NAME;

        if (!bDBCreated) {
            File directory = new File(destDir);
            directory.mkdirs();
            try {
                InputStream is = getAssets().open(DataManager.DBFILE_NAME);
                FileOutputStream os = new FileOutputStream(destPath);
                byte[] buffer = new byte[1024];
                int len;
                while ((len = is.read(buffer)) > 0) {
                    os.write(buffer, 0, len);
                }
                os.close();
                is.close();
                bDBCreated = true;
                savePreference();
            } catch (Exception e) {
                return false;
            }
        }

        G.db = new DataManager(this);
        G.db.Open(destPath);
        return true;
    }
}