package com.ass.testweather;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;

public class ViewActivity extends AppCompatActivity {
    Report report;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);
        int idx = getIntent().getExtras().getInt("report_idx");
        report = G.db.ary_reports.get(idx);

        TextView txtTitle = findViewById(R.id.txt_view_title);
        txtTitle.setText(report.title);

        TextView txtLocation = findViewById(R.id.txt_view_location);
        txtLocation.setText(report.location);

        TextView txtDateTime = findViewById(R.id.txt_view_datetime);
        txtDateTime.setText(report.date);

        TextView txtNote = findViewById(R.id.txt_view_note);
        txtNote.setText(report.note);

        TextView txtTemperature = findViewById(R.id.txt_view_temperature);
        String temp = report.temperature + "°F";
        txtTemperature.setText(temp);

        TextView txtCondition = findViewById(R.id.txt_view_condition);
        txtCondition.setText(report.weather_condition);

        LinearLayout viewPhoto = findViewById(R.id.layout_view_photo);
        String[] photos = report.photo_name.split(";");

        for (int i = 0; i<photos.length; i++) {
            final ImageView img = new ImageView(this);
            LinearLayout.LayoutParams lParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1000);
            lParams.setMargins(30, 50, 30, 0);
            img.setLayoutParams(lParams);
            img.setBackgroundColor(getResources().getColor(R.color.colorPhotoBack));
            String strPath = "/data/data/" + getPackageName() + "/photo/" + photos[i];
            try {
                File file = new File(strPath);
                FileInputStream fis = new FileInputStream(file);
                Bitmap bmp = BitmapFactory.decodeStream(fis);
                img.setImageBitmap(bmp);
                fis.close();
            } catch (Exception e) {

            }
            viewPhoto.addView(img);
        }
    }
}
