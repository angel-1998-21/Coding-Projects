// The following file is going to register the report that is being created. It will get all the information required for each report being created.
package com.ass.testweather;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import android.os.AsyncTask;
import com.androdocs.httprequest.HttpRequest;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

import java.util.ArrayList;
import java.util.List;


// The following class is going to create the report with the needed fields.
public class RegisterActivity extends AppCompatActivity {

    private static final int CAMERA_REQUEST = 555;
    private static final String CITY = "dayton,us";
    //    private static final String API = "8118ed6ee68db2debfaaa5a44c832918";
    private static final String API = "eda613354ca642e40834942dc716f9b0";

    Report report;

    EditText edtTitle;
    EditText edtLocation;
    TextView txtDateTime;
    EditText edtNote;
    TextView txtTemperature;
    TextView txtWeatherCondition;
    LinearLayout viewPhoto;
    List<ImageView> imgPhotos = new ArrayList<>();

    Button btnTakePhoto;
    Button btnRegister;

    String strDate;

    // The following method is going to save the instance that was created as a state.
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        edtTitle = findViewById(R.id.edt_title);
        edtLocation = findViewById(R.id.edt_location);
        txtDateTime = findViewById(R.id.txt_date);
        txtDateTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getIncidentDateTime();
            }
        });
        edtNote = findViewById(R.id.edt_note);
        txtTemperature = findViewById(R.id.txt_temperature);
        txtWeatherCondition = findViewById(R.id.txt_weather_condition);
        viewPhoto = findViewById(R.id.layout_photo);

        btnTakePhoto = findViewById(R.id.btn_take_photo);
        btnTakePhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent cameraIntent = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                if (cameraIntent.resolveActivity(getPackageManager()) != null) {
                    startActivityForResult(cameraIntent, CAMERA_REQUEST);
                }
            }
        });
        btnRegister = findViewById(R.id.btn_register_report);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(view.getContext())
                        .setCancelable(false)
                        .setMessage("Are you sure want to register new report?")
                        .setNegativeButton("No", null)
                        .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                registerReport();
                            }
                        })
                        .show();
            }
        });

        report = new Report();

        new weatherTask().execute();

    }

    // The following is going to get the date and time that was entered for the report
    public void getIncidentDateTime() {
        LayoutInflater li = LayoutInflater.from(this);
        View calendar_view = li.inflate(R.layout.dialog_calendar, null);
        strDate = G.sdformat_MMddyyyy.format(new Date());
        final CalendarView calendar = calendar_view.findViewById(R.id.calendar);

        calendar.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(CalendarView calendarView, int year, int month, int day) {
                strDate = String.format("%d/%d/%d", month + 1, day, year);
            }
        });
        final EditText edtHour = calendar_view.findViewById(R.id.edt_calendaar_hour);
        final EditText edtMinute = calendar_view.findViewById(R.id.edt_calendaar_minute);

        AlertDialog.Builder calBuilder = new AlertDialog.Builder(this);
        calBuilder.setView(calendar_view);
        calBuilder
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String str_datetime = strDate + " " + edtHour.getText() + ":" + edtMinute.getText();
                        txtDateTime.setText(str_datetime);
                        report.date = str_datetime;
                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        dialogInterface.cancel();
                    }
                })
                .show();
    }

    // The following method will register the report using all the information that the user has provided
    public void registerReport() {
        report.id = new Date().getTime();
        report.title = edtTitle.getText().toString();
        report.location = edtLocation.getText().toString();
        report.note = edtNote.getText().toString();

        G.db.insertReport(report);

        report.title = "";
        report.location = "";
        report.date = "";
        report.note = "";
        report.temperature = 0;
        report.weather_condition = "";
        report.photo_name = "";

        edtTitle.setText("");
        edtLocation.setText("");
        txtDateTime.setText(getResources().getString(R.string.select_date));
        edtNote.setText("");
        txtTemperature.setText("");
        txtWeatherCondition.setText("");

        for (int i=0; i<imgPhotos.size(); i++) {
            ImageView img = imgPhotos.get(i);
            viewPhoto.removeView(img);
        }
        imgPhotos.clear();
        new weatherTask().execute();

        edtTitle.requestFocus();
    }

    // The following method will allow the user to retrieve the pictures and information entered with the correct format.
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data)
    {
        if (requestCode == CAMERA_REQUEST && resultCode == Activity.RESULT_OK)
        {
            Bitmap photo = (Bitmap) data.getExtras().get("data");

            String photoDir = "/data/data/" + getPackageName() + "/photo/";
            File directory = new File(photoDir);

            directory.mkdirs();
            String strTimeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            String strPhotoFile = "R" + strTimeStamp + ".png";
            String strPhotoPath = photoDir + strPhotoFile;

            File image = new File(strPhotoPath);
            try {
                FileOutputStream fos = new FileOutputStream(image);
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                photo.compress(Bitmap.CompressFormat.PNG, 100, stream);
                byte[] byteArray = stream.toByteArray();
                fos.write(byteArray);
                fos.close();
            } catch (Exception e) {
            }

            final ImageView img = new ImageView(this);
            LinearLayout.LayoutParams lParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1000);
            lParams.setMargins(30, 50, 30, 0);
            img.setLayoutParams(lParams);
            img.setBackgroundColor(getResources().getColor(R.color.colorPhotoBack));
            img.setImageBitmap(photo);
            imgPhotos.add(img);
            viewPhoto.addView(img);
            if (report.photo_name == null)
                report.photo_name = "";
            report.photo_name += strPhotoFile + ";";
        }
        super.onActivityResult(requestCode, resultCode, data);

    }

    // The following method is going to call the weather api and get the weather for the location.
    void getWeatherFromJson(String strJson) {
        if (strJson == null)
            return;

        try {
            JSONObject jsonObj = new JSONObject(strJson);
            JSONObject main = jsonObj.getJSONObject("main");
            JSONObject weather = jsonObj.getJSONArray("weather").getJSONObject(0);

            String temp = main.getString("temp");
            report.temperature = Double.valueOf(temp) * 1.8 + 32;     //Convert C to F
            temp = String.valueOf(report.temperature);
            txtTemperature.setText(temp + "°F");

            String weatherDescription = weather.getString("description");
            report.weather_condition = weatherDescription;
            txtWeatherCondition.setText(weatherDescription);

        } catch (JSONException e) {
        }

    }

    // This method will execute the weather request. 
    class weatherTask extends AsyncTask<String, Void, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();

        }

        protected String doInBackground(String... args) {
            String response = HttpRequest.excuteGet("https://api.openweathermap.org/data/2.5/weather?q=" + CITY + "&units=metric&appid=" + API);
            return response;
        }

        @Override
        protected void onPostExecute(String result) {

            getWeatherFromJson(result);
        }
    }

}
