// The following method will allow us to browse through all the reports and also have a search bar in case the user wants to speed things up and enter the title of the incident.
package com.ass.testweather;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Button;

// The following method is going to get the saved instances of the report and display them to the user.
public class BrowseActivity extends AppCompatActivity {
    EditText edtSearchWord;
    Button btnSearch;
    ListView lstReport;
    ReportListAdapter adapterLstReport;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browse);
        G.db.getReports("");

        edtSearchWord = findViewById(R.id.edt_search_word);
        btnSearch = findViewById(R.id.btn_search);
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String strSearchWord = edtSearchWord.getText().toString();
                if (strSearchWord.isEmpty())
                    G.db.getReports("");
                else
                    G.db.getReports(strSearchWord);
                lstReport.invalidateViews();
            }
        });
        lstReport = findViewById(R.id.lst_reports);
        adapterLstReport = new ReportListAdapter(this);
        lstReport.setAdapter(adapterLstReport);
        lstReport.invalidateViews();
        lstReport.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                Intent intent = new Intent(BrowseActivity.this, ViewActivity.class);
                intent.putExtra("report_idx", i);
                startActivity(intent);
            }
        });

    }

    // The following method is going to allow for the report to adapt/update every time a new report is entered and output the updated list to the user.
    class ReportListAdapter extends BaseAdapter {
        Context context;
        LayoutInflater inflater;

        public ReportListAdapter(Context context) {

            this.context = context;
            this.inflater = LayoutInflater.from(context);
        }

        @Override
        public int getCount() {
            return G.db.ary_reports.size();
        }

        @Override
        public Object getItem(int i) { return G.db.ary_reports.get(i); }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View view, ViewGroup viewGroup) {

            final Report cur_info = G.db.ary_reports.get(i);

            View layout = (view == null) ? inflater.inflate(R.layout.listitem_report, null):view;

            TextView item_title = layout.findViewById(R.id.item_title);
            item_title.setText(cur_info.title);

            TextView item_birthday = layout.findViewById(R.id.item_datetime);
            item_birthday.setText(cur_info.date);

            TextView item_location = layout.findViewById(R.id.item_location);
            item_location.setText(cur_info.location);

            TextView item_note = layout.findViewById(R.id.item_note);
            item_note.setText(cur_info.note);

            return layout;
        }
    }
}
