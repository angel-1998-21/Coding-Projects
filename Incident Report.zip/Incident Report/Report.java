package com.ass.testweather;

public class Report {
    long id;
    String title;
    String location;
    String date;
    String note;
    double temperature;
    String weather_condition;
    String photo_name;
}
